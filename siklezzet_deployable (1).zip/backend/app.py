
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)

users = []
items = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    hashed_password = generate_password_hash(data['password'])
    user = {
        "email": data['email'],
        "phone": data['phone'],
        "id_card": data['id_card'],
        "password": hashed_password,
        "role": data['role']
    }
    users.append(user)
    return jsonify({"message": "Signup successful"}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    for user in users:
        if user['email'] == data['email'] and check_password_hash(user['password'], data['password']):
            return jsonify({"message": "Login successful"}), 200
    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/items', methods=['POST'])
def add_item():
    data = request.json
    item = {
        "title": data['title'],
        "category": data['category'],
        "type": data['type'],  # rent/sell/borrow
        "conditions": data.get('conditions', {}),
        "owner": data['owner']
    }
    items.append(item)
    return jsonify({"message": "Item added"}), 201

if __name__ == '__main__':
    app.run(debug=True)
